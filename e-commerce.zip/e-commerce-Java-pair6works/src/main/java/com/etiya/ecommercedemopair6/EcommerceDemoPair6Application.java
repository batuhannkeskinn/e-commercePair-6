package com.etiya.ecommercedemopair6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommerceDemoPair6Application {

	public static void main(String[] args) {
		SpringApplication.run(EcommerceDemoPair6Application.class, args);
	}

}
